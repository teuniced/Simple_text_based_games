from random import choice as c
import random
import time
import statistics as stats

print(" Random Number game ".center(60, "~"))
player_choice = 4
computer_choice = random.randint(1, 10)
if player_choice == computer_choice:
    # This (print statements) shows results for computer_choice and player_choice while                                                         if statement checks if each condition is met
    print('The computer has the same number')
    print(
        f"Player picked {player_choice} and computer picked {computer_choice}")
elif player_choice > computer_choice:
    print(
        f"The computer has a lower number: Player picked {player_choice} and computer picked {computer_choice}"
    )
else:
    print('The computer has a higher number')
    print(
        f"Player picked {player_choice} and computer picked {computer_choice}")



print(" Rock paper scissors game ".center(60, "~"))
my_points, computer_points = 0, 0
computer_selection = random.randint(1, 4)
while True:
    print(f"\nComputer Score: {computer_points}\tMy Score: {my_points}\n")
    #an instruction can be given to players to striclty follow choice lettercase or a similar .lower()method can be used to fit users input
    my_selection = input("Enter a choice (rock, paper, scissors,tolu): ")
    if my_selection == 'rock':
        my_selection = 1
    elif my_selection == 'paper':
        my_selection = 2
    elif my_selection == 'scissors':
        my_selection = 3
    elif my_selection == "tolu":
        my_selection = 4
    else:
        my_selection = input(
            "Please enter a valid choice (rock, paper, scissors,tolu): "
        )  #maybe a way to keep players to follow the rules? if choice is not valid. This runs again to allow users pick a valid choice.
        if my_selection == 'rock':
            my_selection = 1
        elif my_selection == 'paper':
            my_selection = 2
        elif my_selection == 'scissors':
            my_selection = 3
        elif my_selection == "tolu":
            my_selection = 4

    computer_selection = random.randint(
        1, 4
    )  #important to keep this in the while loop else the first random number picked by computer outside the loop will run all through the loop making the game biased.
    print(
        f"You picked {my_selection} and the computer picked {computer_selection}\n"
    )

    if my_selection < computer_selection:
        print("Computer wins!")
        computer_points += 1
    elif my_selection > computer_selection:
        print("You win!")
        my_points += 1
    else:
        print("It is a tie!")

    if computer_points == 5 or my_points == 5:  #condition for which the loop breaks(i.e the game ends)
        break
print(" Game over! Final Score".center(75, "~"))
print(f"Computer Score: {computer_points}\nPlayer Score: {my_points}\n")





print(" Text-Based Board Game ".center(60, "~"))
start_end = "Please pick a number from 1 - 37: "  #prompt to start playing the game
user_match = 0  #match point score for players
comp_match = 0
gameround = 0
userinput_list = []  
#empty list that soon houses user inputs from "user_input" variable
compinput_list = []

while gameround <= 9:  #gameround used here as the game end counter <=9 because initial number is '0'
    gameround += 1  #iterates and prints what round is being played at the moment
    print(f"\nRound {gameround}")
    #user input stored in variable user_input and also as an "integer"
    user_input = int(input(start_end))
    comp_input = random.randint(1, 37)  #acts as the dealer

    if comp_input == 37:
        comp_input = 0
    elif user_input == 37:
        user_input = 0

    if user_input < 38:
        userinput_list.append(user_input)  #helps to store inputs from players
        compinput_list.append(comp_input)
    if user_input > 37:
        print("Hmm..that's not a valid number!!!")
        user_input = int(input(start_end))

    print(f"\n\t\tComputer Input: {comp_input}\tUser Input: {user_input}")
    if (user_input % 2) == 0:  #condition for "odd/even"
        #if user_input which is an integer after it’s divided by 2 gives an output with zero remainder then,
        print(f"\t\tUser_input is even")
    else:
        print(f"\n\t\tUser_input is odd")
    if user_input in range(1, 19):  #1-19 because range so its 1-18 ,
        #different if statement because it's a different condition set
        print("\t\tLow match for user")
    else:
        print("\t\tHigh match for user")

    if comp_input == user_input:
        print("\t\tIt is an exact match. Player wins!")
        user_match += 1
    print(f"\t\tTotal win match for user: {user_match}")
    print(f"\t\tUser input median number: {stats.median(userinput_list)}")
    print(
        f"Computer input list: {compinput_list},User input list: {userinput_list}"
    )
    quit_input = input("Hit <Enter> to resume or Type 'q' to exit the game\n")
    if (quit_input.lower()
        ) == 'q':  #prompt to allow user quit playing the game by choice
        print(" Game Over ".center(60, "-"))
        break
    else:
        continue
print("Game Summary".center(60, "-"), '\nPlayer Match(es):', user_match)
time.sleep(2)






